# Airfare Test Harness

This project contains 5 standalone mock airfare websites/services for testing scraper development.

## Setup

```bash
pip install -r requirements.txt
python server.py
```

The service is available at: `http://127.0.0.1:8765`

## API Keys

* SkyFly (Site 1): `TEST_API_KEY_SITE1_123`
* AeroNation (Site 2): `TEST_API_KEY_SITE2_456`
