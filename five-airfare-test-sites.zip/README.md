# Airfare Test Harness

This project contains 5 standalone mock airfare websites/services for testing airfare scrapers.

## Installation

```bash
pip install -r requirements.txt
python server.py
```

Accessible at `http://127.0.0.1:8765`

## Websites

1. **SkyFly (site1-api)**: API airline. Routes: `/site1-api/flights`
2. **AeroNation (site2-api)**: Unstable API airline. Routes: `/site2-api/flights`, `/site2-api/test/*`
3. **JetVista (site3-html)**: HTML scraping website. Routes: `/site3-html/`, `/site3-html/index.html`, `/site3-html/normal.html`
4. **FlySphere (site4-html)**: Dynamic JS-heavy airline. Routes: `/site4-html/`
5. **AirZen (site5-html)**: Difficult scraping + failures. Routes: `/site5-html/`

## Requirements

- Python 3
- Flask
