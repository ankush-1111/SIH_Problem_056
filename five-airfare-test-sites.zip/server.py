from flask import Flask, jsonify, request, render_template, Response
import json
import os
import time

app = Flask(__name__, template_folder='C:/Users/ankus/OneDrive/Documents/SIH/SIH_Problem_056/five-airfare-test-sites/')

DATA_PATH = "C:/Users/ankus/OneDrive/Documents/SIH/SIH_Problem_056/five-airfare-test-sites/data/"

def load_data(site):
    with open(os.path.join(DATA_PATH, f"{site}.json"), 'r') as f:
        return json.load(f)

# Home
@app.route('/')
def index():
    return "Airfare Test Harness - Sites: 1-API, 2-API, 3-HTML, 4-HTML, 5-HTML"

# --- Site 1: SkyFly API ---
@app.route('/site1-api/flights', methods=['GET'])
def site1_flights():
    if request.headers.get('X-API-Key') != 'TEST_API_KEY_SITE1_123':
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(load_data('site1'))

@app.route('/site1-api/test/<case>', methods=['GET'])
def site1_test(case):
    if case == 'no-results': return jsonify({"flights": []})
    if case == 'sold-out': return jsonify({"flights": [{"availability": "sold_out"}]})
    return jsonify({"error": "Case not implemented"})

# --- Site 2: AeroNation API ---
@app.route('/site2-api/flights', methods=['GET'])
def site2_flights():
    if request.headers.get('X-API-Key') != 'TEST_API_KEY_SITE2_456':
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(load_data('site2'))

@app.route('/site2-api/test/<case>', methods=['GET'])
def site2_test(case):
    if case == 'rate-limit': return Response("Rate Limit Exceeded", status=429, headers={"Retry-After": "5"})
    if case == 'unauthorized': return jsonify({"error": "Unauthorized"}), 401
    if case == 'forbidden': return jsonify({"error": "Forbidden"}), 403
    if case == 'server-error': return jsonify({"error": "Internal Server Error"}), 500
    if case == 'timeout':
        time.sleep(10)
        return jsonify({"result": "success"})
    if case == 'malformed-json': return Response("This is not JSON", mimetype='application/json')
    return jsonify({"error": "Case not implemented"})

# --- Sites 3, 4, 5 - HTML ---
@app.route('/<site_dir>/', defaults={'filename': 'index.html'})
@app.route('/<site_dir>/<filename>')
def serve_html(site_dir, filename):
    return render_template(os.path.join(site_dir, filename))

if __name__ == '__main__':
    app.run(port=8765)
