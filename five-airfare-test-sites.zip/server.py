from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import json
import os
import time

app = FastAPI()

# Serve static files for each site
app.mount("/site3", StaticFiles(directory="site3-html"), name="site3")
app.mount("/site4", StaticFiles(directory="site4-html"), name="site4")
app.mount("/site5", StaticFiles(directory="site5-html"), name="site5")

# Helper to load data
def load_data(site_id):
    with open(f"data/site{site_id}.json", "r") as f:
        return json.load(f)

# --- Site 1: SkyFly (Normal API) ---
@app.get("/site1-api/flights")
async def site1_flights(x_api_key: str = Header(None)):
    if x_api_key != "TEST_API_KEY_SITE1_123":
        raise HTTPException(status_code=401, detail="Unauthorized")
    return load_data(1)

@app.get("/site1-api/test/no-results")
async def site1_no_results(x_api_key: str = Header(None)):
    if x_api_key != "TEST_API_KEY_SITE1_123":
        raise HTTPException(status_code=401, detail="Unauthorized")
    return {"search": {}, "flights": []}

# --- Site 2: AeroNation (Unstable API) ---
@app.get("/site2-api/flights")
async def site2_flights(x_api_key: str = Header(None)):
    if x_api_key != "TEST_API_KEY_SITE2_456":
        raise HTTPException(status_code=401, detail="Unauthorized")
    return load_data(2)

@app.get("/site2-api/test/rate-limit")
async def site2_rate_limit():
    raise HTTPException(status_code=429, detail="Rate limit exceeded", headers={"Retry-After": "5"})

@app.get("/site2-api/test/server-error")
async def site2_server_error():
    raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get("/site2-api/test/timeout")
async def site2_timeout():
    time.sleep(5)
    return {"message": "Timed out"}

# --- Generic Homepage ---
@app.get("/", response_class=HTMLResponse)
async def root():
    return """
    <html>
        <body>
            <h1>Airfare Test Harness</h1>
            <ul>
                <li><a href="/site3/">JetVista (Site 3)</a></li>
                <li><a href="/site4/">FlySphere (Site 4)</a></li>
                <li><a href="/site5/">AirZen (Site 5)</a></li>
            </ul>
        </body>

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8765)
